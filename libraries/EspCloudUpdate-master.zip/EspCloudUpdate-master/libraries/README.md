# EspCloudUpdate [![N|Solid](http://sanusb.blogspot.com.br/favicon.ico)](http://sanusb.org/)

 
 You can usually install the Firebase and EspCLoudUpdate libraries as Tutorial: https://youtu.be/En_hFO5f4U8 or past the tested folder libraries at:
  
 On Windows:    
*        C:\Users\UserName\Documents\Arduino\libraries. 
     
 On Linux:   
*       /home/UserName/Arduino/Libraries.

On OSX:
*       ~/Documents/Arduino/libraries.

 
 
*Have fun!*
